create definer = root@localhost trigger PagoTransacciones_BEFORE_INSERT
    before insert
    on pagostransacciones
    for each row
BEGIN
    DECLARE totalVentas DECIMAL(10,2);
    DECLARE totalAlquileres DECIMAL(10,2);
    DECLARE totalPago DECIMAL(10,2);

SELECT IFNULL(SUM(pvc.MontoVenta), 0)
INTO totalVentas
FROM PagosTransacciones pt
JOIN ProductosVenta_Clientes pvc
ON pvc.idCompra = pt.idCompra
WHERE pt.idTransaccion = NEW.idTransaccion;

SELECT IFNULL(SUM(pac.MontoAlquiler), 0)
INTO totalAlquileres
FROM PagosTransacciones pt
JOIN ProductosArrendamiento_Clientes pac
ON pac.idAlquiler = pt.idAlquiler
WHERE pt.idTransaccion = NEW.idTransaccion;
    
    SET totalPago = totalVentas + totalAlquileres;
    SET NEW.MontoTransaccion = totalPago;
END;

